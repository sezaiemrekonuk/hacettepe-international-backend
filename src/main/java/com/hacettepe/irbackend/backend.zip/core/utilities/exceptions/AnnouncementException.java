package com.hacettepe.irbackend.core.utilities.exceptions;

public class AnnouncementException extends RuntimeException {
    public AnnouncementException(String message) {
        super(message);
    }
}
